// Shadow state:
module.exports =
{
  "reported": {
    "Temperature": 33,
    "Humidity": 37,
    "Pressure": 640
  }
}

// Fuction from Alexa and Google Home:
// 1: descover each sensor individauly.
// 2: Able to get temprature from device and report temprature, humidity and presure.
// 3: And alert when temprature cross the thershold value.

