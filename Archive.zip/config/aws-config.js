module.exports ={
  AWS_KEY: 'AKIAUPIJEFM652WJKN3A',
  AWS_SECRET: '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',
  AWS_IOT_BROKER_ENDPOINT:"a3ca3lp4kvh6ns-ats.iot.ap-south-1.amazonaws.com",
  AWS_IOT_BROKER_REGION:"ap-south-1",
  AWS_IOT_THING_NAME:"alexa_board"
};
